def sqrt_list(l):
        return [x**0.5 for x in l]